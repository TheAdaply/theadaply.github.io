# Working agreement
Use the existing project conventions.
Keep changes focused on the requested task.
For UI tasks, follow the ui-spec skill before implementation.
Resolve product decisions with the user; cite precedent for inferred details.
Report checks actually run, results and anything left unchecked.
