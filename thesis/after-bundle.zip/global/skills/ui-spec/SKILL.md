---
name: ui-spec
description: Specify and implement a UI change.
---
Read the brief, repository design documentation and relevant components.
Use available captured review corrections as evidence, not automatic authority.
Draft a state matrix: state, expected behavior, precedent, acceptance check.
Consider loading, empty, error, permission, narrow-layout and keyboard states.
Include only relevant states; explain exclusions.
Cite repository rules or accepted patterns for supported details.
Label unsupported details as proposals. Ask the user about unresolved product choices.
For invitations, resolve who may invite before implementing that permission.
After resolving choices, implement with existing components and targeted tests.
Request ui-reviewer review of the changed files and acceptance cases.
Use existing authorized browser tooling for rendered-state and keyboard checks.
If unavailable, report browser review as outstanding; request manual review.
Report commands, results and unchecked cases.
