#!/usr/bin/env python3
print("Use the project conventions and keep the change focused.")
print("For UI tasks: follow ui-spec; resolve product choices; report checks actually run.")
