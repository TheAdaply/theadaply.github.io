---
name: api-regression
description: Fix a bug in an existing API endpoint.
---
Read the endpoint and its existing tests.
Write a regression case and observe it fail before the fix.
For auth changes, cover valid, missing and expired credentials.
Reuse existing helpers. Make the smallest fix.
Run the affected test file after the fix.
Record the command, exit status and any cases left unchecked.
