# Working agreement
Use the existing project conventions.
Keep changes focused on the requested task.
For API fixes, follow the api-regression skill.
Report each check you actually ran and its result.
If a check could not run, name it and explain why.
