#!/usr/bin/env python3
print("Use the project conventions and keep the change focused.")
print("For API fixes: follow api-regression; report only checks you ran.")
