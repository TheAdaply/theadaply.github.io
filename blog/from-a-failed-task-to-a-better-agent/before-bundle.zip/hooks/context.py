#!/usr/bin/env python3
print("Use the project conventions and keep the change focused.")
