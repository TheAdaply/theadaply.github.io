# Working agreement
Use the existing project conventions.
Keep changes focused on the requested task.
Summarize the change and its tests when finished.
