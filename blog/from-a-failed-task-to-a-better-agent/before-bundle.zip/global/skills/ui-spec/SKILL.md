---
name: ui-spec
description: Specify and implement a UI change.
---
Read the brief and existing components.
Reuse the design system. Keep changes focused.
Run relevant checks and summarize the result.
