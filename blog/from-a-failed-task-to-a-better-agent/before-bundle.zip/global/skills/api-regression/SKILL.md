---
name: api-regression
description: Fix a bug in an existing API endpoint.
---
Read the endpoint and its existing tests.
Reuse existing helpers. Make the smallest fix.
Run the relevant tests and summarize the result.
